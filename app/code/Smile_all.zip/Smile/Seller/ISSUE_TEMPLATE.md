<!--- Provide a general summary of the issue in the Title above -->

### Preconditions
<!--- Please Provide detailed informations about the environment you use -->

<!-- Magento Version : Are you using Magento CE or EE ? Which version of Magento are you using exactly ? -->
Magento Version :

<!-- Module Map Version : Which exact version of Module Map are you using ? -->
Module Seller Version :

<!-- Magento Environment : are you in Developer or Production mode ? -->
Environment :

<!-- Third party modules : are you using any third party modules ? If yes, please attach the list -->
Third party modules :

### Steps to reproduce
<!--- Provide a set of unambiguous steps to reproduce this bug. You can also include pieces of code if you think it's relevant  -->
1.
2.
3.

### Expected result
<!--- Tell us what should happen -->
1.

### Actual result
<!--- Tell us what happens instead -->
1. [Screenshot, logs]

<!--- (This may be platform independent comment) -->
