## Smile Seller

It allows to add sellers.

### Requirements

### How to use

1. Install the module via Composer :

``` composer require smile/module-seller ```

2. Enable it

``` bin/magento module:enable Smile_Seller ```

3. Install the module and rebuild the DI cache

``` bin/magento setup:upgrade ```

