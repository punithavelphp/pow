var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Ecomteck_DeliveryDate/js/model/shipping-save-processor/default'
        }
    }
};