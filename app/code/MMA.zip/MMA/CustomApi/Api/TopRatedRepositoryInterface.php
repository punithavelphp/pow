<?php

namespace MMA\CustomApi\Api;

interface TopRatedRepositoryInterface extends ProductsRepositoryInterface {

}