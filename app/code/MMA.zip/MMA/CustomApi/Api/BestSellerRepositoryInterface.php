<?php

namespace MMA\CustomApi\Api;

interface BestSellerRepositoryInterface extends ProductsRepositoryInterface {
}