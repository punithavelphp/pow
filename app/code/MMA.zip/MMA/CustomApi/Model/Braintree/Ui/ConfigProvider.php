<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace MMA\CustomApi\Model\Braintree\Ui;;

use MMA\CustomApi\Api\BraintreeConfigProviderInterface;

/**
 * Class ConfigProvider
 */
class ConfigProvider extends \Magento\Braintree\Model\Ui\ConfigProvider implements BraintreeConfigProviderInterface
{

}
