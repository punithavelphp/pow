/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
var config = {
	map: {
		"*": {
			conflict: "Ves_Brand/js/conflict",
			owlcarousel: "Ves_Brand/js/owl.carousel",
			boostrap: "Ves_Brand/js/bootstrap.min",
		}
	}
};