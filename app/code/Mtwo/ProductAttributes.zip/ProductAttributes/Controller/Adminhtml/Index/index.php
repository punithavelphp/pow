<?php

namespace Mtwo\ProductAttributes\Controller\Adminhtml\Index;

class Index extends \Magento\Backend\App\Action {

    protected $resultPageFactory = false;

    /**
     * Initialize
     *
     * @param Action\Context $context           Initialize Context
     * @param PageFactory    $resultPageFactory Initialize resultPageFactory
     */
    public function __construct(
    \Magento\Backend\App\Action\Context $context, \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Return Title
     *
     * @return Careers
     */
    public function execute() {


        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $helper = $objectManager->create('\Mtwo\ProductAttributes\Helper\Data');

        $attributeCode = 'color';
        $labelArray[$attributeCode][] = array('Black', 'Red', 'White', 'Red Transparent', 'Blue Transparent', 'Silver Tech', 'Camouflage', 'Desert Camouflage', 'Navy Camouflage', 'Stainless Steel', 'Silver', 'Cream');
        $labelArray[$attributeCode][] = array('White', 'Black', 'Aqua');
        $labelArray[$attributeCode][] = array('Black-fushia', 'Black-red', 'Black', 'Navy Blue-orange', 'Grey-orange', 'Grey-green', 'Brown-green', 'Brown', 'Clear', 'Smoke', 'Navy Blue-royal Blue', 'Green-black', 'White', 'Warm White', 'Blue', 'Ceramic Black', 'Ceramic White', 'Rad', 'Yellow', 'Green', 'Green & Yellow', 'Grey 48', 'Black 72', 'Grey 72', 'Gold', 'Silver', 'Grey', 'Prism Blue', 'Prism Green', 'Prism Black', 'Prism Silver', 'Prism White', 'Red', 'Deep Blue', 'Angel Gold', 'Phantom Black', 'Ghost White', 'Charcoal Black', 'Ocean Blue', 'Honey', 'Tan', 'Orange', 'Tropical', 'Glacier', 'Jet Black', 'Sliver', 'Navy Blue', 'Royal Blue', 'Pink', 'Bottle Green', 'Dark', 'Desert Tan', 'Od Green', 'Photoluminescent', 'Hellpink', 'Red Transparent', 'Blue Transparent', 'Camouflage', 'Chocolate', 'Desert Camouflage', 'Silver Tech', 'Multicolor', 'Desert Camouflage', 'Navy Camouflage', 'Gray', 'Small Gray', 'Midnight-green', 'Coral', 'Rose Gold', 'Grey-yellow', 'Sandbrown', 'Prism Crush Black', 'Stainless Steel', 'Cream', 'Lemon', 'Lime', 'Original', 'Lavender', 'Light', 'Cyan', 'Magenta', 'Slate', 'Black/black', 'Blue/black', 'Red/black', 'Carbon', 'Blue Camo', 'Violet', 'Purple', 'Aqua', 'Triple Black', 'Lux Silver', 'Navy Citron', 'Orange Navy', 'Soapstone', 'Beige', '#', 'Mixed', 'Turquoise', 'Green1', 'Copper Metallic', 'Yellow-black', 'Fuchsia Pink', 'Ivory', 'Moss', 'Matte Gold', 'Matte Silver', 'Gloss Black', 'Satin Silver', 'Satin Gold', 'Rose-gold', 'Defiant Black-red', 'Asphalt Gray', 'Gloss White', 'Navy White', 'Turf Green', 'Brick Red', 'Break Blue', 'Citrus Red', 'Pop Violet', 'Pop Blue', 'Pop Magenta', 'Pop Indigo', 'Club Navy', 'Club Yellow', 'Club Red', 'Balck', 'Yellow Green');
        $labelArray[$attributeCode][] = array('White', 'Warm White', 'Rgb', 'Warm-white', 'Brown');
        $labelArray[$attributeCode][] = array('Prism Black', 'Prism White', 'Prism Silver');


        $attributeCode = 'size';
        $labelArray[$attributeCode][] = array('S', 'M', 'L', 'XL', 'XXL');
        $labelArray[$attributeCode][] = array('27.5"', '29"');
        $labelArray[$attributeCode][] = array('16 Inch', '18 Inch', '20 Inch', '24 Inch', '8"', '10"', '8 Inch', '12 Inch', '10 Inch', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', 'Xs', 'S', 'M', 'L', 'Xl', 'XXL', '3xl', '48', '7 Inch', '9 Inch', 'No.01', 'No.02', 'No.04', '3s', '4s', '5s', '20cm', '23cm', '26cm', '22 Cm', '24 Cm', '26 Cm', '28 Cm', '32 Cm', '34 Cm', '50 Cm', '20 Cm', '36 Cm', '14 Cm', '16 Cm', '9 Mm X 130 Mm', '10 Mm X 140 Mm', '4 Mm X 80 Mm', '6 Mm X 100 Mm', '5 X 100/ 160 Mm', '6 X 100/ 160 Mm', '8 X 100/160 Mm', '8 X 150/210 Mm', '10 X 100/160 Mm', '10 X 150/210 Mm', '12 X 100/160 Mm', '12 X 150/210 Mm', '12 X 240/300 Mm', '12 X 400/460 Mm', '14 X 100/160 Mm', '14 X 150/210 Mm', '16 X 150/210 Mm', '16 X 240/300 Mm', '16 X 400/460 Mm', '18 X 150/210 Mm', '18 X 240/300 Mm', '18 X 400/460 Mm', '18 X 540/600 Mm', '18 X 940/1000 Mm', '20 X 150/210 Mm', '20 X 400/460 Mm', '20 X 940/1000 Mm', '22 X 200/260 Mm', '25 X 200/260 Mm', '16 X 200/340 Mm', '16 X 400/540 Mm', '18 X 200/340 Mm', '18 X 400/540 Mm', '20 X 200/320 Mm', '20 X 400/520 Mm', '22 X 200/320 Mm', '22 X 400/520 Mm', '24 X 200/320 Mm', '24 X 400/520 Mm', '25 X 200/320 Mm', '25 X 400/520 Mm', '28 X 250/370 Mm', '28 X 450/570 Mm', '28 X 550/670 Mm', '30 X 250/370 Mm', '30 X 450/570 Mm', '16 X 126/191 Mm', '16 X 335/400 Mm', '18 X 126/191 Mm', '18 X 335/400 Mm', '20 X 126/191 Mm', '20 X 335/400 Mm', '25 X 126/191 Mm', '25 X 335/400 Mm', '28 X 335/400 Mm', '24"', '36"', '48"', '1"', '1.5"', '2"', '3"', '2xl', '10', '12', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '29', '32', '34', '50', '54', '55', '75', '30', '6', '7', '8', '9', '28', '31', '60', '80', '100', '120', '150', '200', '4.5', '4.5"', '7"', '9"', '12"', '1.5mm', '2.5mm', '4mm', '10mm', '300mm', '2mm', '6"', '4"', '5"', '180', '220', '320', '3mm', '6mm', '8mm', '5mm', '12mm', '13mm', '16mm', '25mm', '20mm', '32mm', '38mm', '50mm', '54mm', 'A2', 'A4', '2 "', '3 "', '4 "', '6 "', '1/2x50 Mtr', '1x50 Mtr', '3/4x50 Mtr', '1/2"mtr', '3/4"mtr', '1"mtr', '1/2"', '2.5"', '1/2"x50', '500', '800', '1000', '2000', '14mm', '18mm', '22mm', '24mm', '16k', '24k', '32k', '3mtr', '5mtr', '5.5mtr', '7.5mtr', '10mtr', '11', '3', '4', '5', '5.5', '11.5', '13', '38"', '40"', '42"', '44"', '46"', '50"', '52"', '54"', '4xl', '5xl', '550 W', '800 W', '14 Watt', '15 Watt', '20 Watt', '24 Watt', 'Kids', '500ml', '750ml', '1l', '3l', '250ml', '40.5', '41.5', '42.5', '43.5', '44.5', '46.5', '29*15.5', '29*17');
        $labelArray[$attributeCode][] = array('2 "', '3 "', '4 "', '6 "');
        $labelArray[$attributeCode][] = array('M', 'L', 'XXL');
        $labelArray[$attributeCode][] = array('50 Mtr', '80 Mtr');

        $attributeCode = 'characteristics';
        $labelArray[$attributeCode][] = array('Straight', 'Right', 'Left', 'Floral', 'Original', 'Spring', 'Valley Breeze', 'Bakhoor', 'Floral Scent', 'Lemon', 'Oud');

        $attributeCode = 'wattage';
        $labelArray[$attributeCode][] = array('3w', '6w', '9w', '12w', '18w', '30w', '20w', '7w', '25w', '45w');
        $labelArray[$attributeCode][] = array('50w', '100w', '200w', '300w');

        $attributeCode = 'liter';
        $labelArray[$attributeCode][] = array('8.3 L', '9.6 L', '12 L', '16 L', '20 L', '24 L', '32 L', '60 L', '80 L');
        $labelArray[$attributeCode][] = array('7 L', '11 L', '16 L', '22 L', '40 L', '8 L', '15 L', '20 L', '25 L', '30 L', '2 L', '3.5 L', '4.5 L', '6 L', '7.6 L', '10 L', '1.5 L', '2.5 L', '5 L', '9 L', '150 Ml', '350 Ml', '710 Ml', '1.1 L', '1.7 L');

        $attributeCode = 'lenght_pieces';
        $labelArray[$attributeCode][] = array('3.5 Mm-10 Pcs', '4.5 Mm-10 Pcs', '5 Mm- 10 Pcs', '5.5 Mm- 10 Pcs', '6.5 Mm- 10 Pcs', '7.5 Mm- 5 Pcs', '8.5 Mm- 5 Pcs', '11 Mm- 5 Pcs', '13 Mm- 5 Pcs', '15 Mm');
        $labelArray[$attributeCode][] = array('3.5 Mm- 10 Pcs', '4.5 Mm- 10 Pcs', '5 Mm- 10 Pcs', '7 Mm- 10 Pcs', '8 Mm- 5 Pcs', '9 Mm- 5 Pcs', '11 Mm- 5 Pcs', '13 Mm- 5 Pcs');

        $attributeCode = 'resolution';
        $labelArray[$attributeCode][] = array('2mp (1920 X 1080)', '3mp (2048 X 1536)', '2 MP (1)', '2 Mp (2)', '4 Mp (1)', '4 Mp (2)', '5 Mp');

        $attributeCode = 'bytes';
        $labelArray[$attributeCode][] = array('4 Gb');

        $attributeCode = 'package';
        $labelArray[$attributeCode][] = array('Pieces', 'Box(50 Pieces)');

        $attributeCode = 'quantitiy';
        $labelArray[$attributeCode][] = array('1', '25');

        echo '<pre>----->' . __FILE__ . '--->' . __LINE__ . '--->';
        print_r($labelArray);
        echo '</pre>';


        foreach ($labelArray as $attributeCode => $labelArry) {
            foreach ($labelArry as $labelArr) {
                foreach ($labelArr as $label) {
                    // $id = $helper->createOrGetId($attributeCode, $label);
                    echo '<pre>----->' . __FILE__ . '--->' . __LINE__ . '--->';
                    print_r($label);
                    echo '</pre>';
                }
            }
        }
        die;
    }

}
