var config = {
  "map": {
    "*": {
      "Magento_Customer/js/model/customer-addresses": "Mtwo_Pickup/js/model/customer-addresses",
       "Magento_Checkout/js/model/shipping-rate-processor/customer-address": "Mtwo_Pickup/js/model/shipping-rate-processor/customer-address",
		       "Magento_Checkout/js/model/shipping-rate-processor/new-address": "Mtwo_Pickup/js/model/shipping-rate-processor/new-address"

    }
  }
};